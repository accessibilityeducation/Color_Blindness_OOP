package SolutionCode;
interface AccessibleDesign {
    String getAccessibleDesignRecommendations();
}
