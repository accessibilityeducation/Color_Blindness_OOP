package SolutionCode;
public class ColorBlindness extends Disability {
    private String impactOnVision;
    private String type;        // Used to get the type of disability in the main method

    public ColorBlindness(String type, String name, String description, String impactOnVision) {
        super(name, description);
        this.impactOnVision = impactOnVision;
        this.type = type;
    }

    public String getImpactOnVision() {
        return impactOnVision;
    }

    public String getType() {
        return type;
    }

    // Subclass specific methods
    public static String getDefinition(String colorBlindnessType) {
        switch (colorBlindnessType) {  
            case "protanomaly":
                return "A type of red-green color blindness where red cones do not detect enough red and are too sensitive to greens, yellows, and oranges.";
            case "protanopia":
                return "A severe form of red-green color blindness where there is a total absence of red cone cells.";
            case "deuteranomaly":
                return "The most common type of red-green color blindness.";
            case "deuteranopia":
                return "A type of red-green color blindness where green cones are absent.";
            case "tritanomaly":
                return "A very rare form of color blindness affecting the blue-yellow spectrum, with limited blue cone cells.";
            case "tritanopia":
                return "A very rare form of color blindness affecting the blue-yellow spectrum.";
            default:
                return "Not a recognized type of color blindness.";
        }
    }

    public static String getImpactOnVisionExplanation(String colorBlindnessType) {
        switch (colorBlindnessType) {  
            case "protanomaly":
                return "colors appear more green and less bright.";
            case "protanopia":
                return "red appears black.";
            case "deuteranomaly":
                return "some greens appear more red.";  
            case "deuteranopia":
                return "I cannot distinguish between red and green colors.";
            case "tritanomaly":
                return "blue appears greener and it can be difficult to distinguish yellow and red from pink.";
            case "tritanopia":
                return "I cannot distinguish between blue and green, and yellow and violet.";
            default:
                return null;
        }
    }
}
