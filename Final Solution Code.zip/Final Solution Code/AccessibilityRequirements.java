package SolutionCode;

import java.util.Random;

public class AccessibilityRequirements implements AssistiveTechnology, AccessibleDesign, EnvironmentalAssistance {

    public String getRecommendedAssistiveTechnologies() {
        return "assistive technology solutions like screen readers, high-contrast themes, and color adjustment software is incredibly helpful. These tools enhance digital accessibility for me, making it easier to distinguish colors and read text on various devices and applications.";
    }

    public String getAccessibleDesignRecommendations() {
        return "digital tools such as color blindness simulators and color identification apps has been a game-changer. They help me design and interact with content more effectively, ensuring I can access information despite my color vision deficiencies.";
    }

    public String getEnvironmentalAssistance() {
        return "improved lighting and using clear, high-contrast signage, make a big difference in my daily navigation. Tactile markers are also a boon, making spaces more accessible and comfortable for me to move around in.";
    }
    
    public String getRandomAssistance() {
        Random random = new Random();
        int choice = random.nextInt(3);
        switch (choice) {
            case 0:
                return getEnvironmentalAssistance();
            case 1:
                return getAccessibleDesignRecommendations();
            case 2:
                return getRecommendedAssistiveTechnologies();
            default:
                return "General assistance";
        }
    }
}
