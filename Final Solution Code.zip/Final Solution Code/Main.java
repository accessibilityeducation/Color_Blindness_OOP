package SolutionCode;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for persona details
        System.out.print("Please create your persona's name: ");
        String personaName = scanner.nextLine();

        // Create the accessibility requirements
        AccessibilityRequirements accessibilityRequirements = new AccessibilityRequirements();

        // Select color blindness type
        ColorBlindness selectedDisability = handleColorBlindnessSelection(scanner);

        // Create the persona with the given name, selected disability, and accessibility requirements
        Human persona = new Human(personaName, selectedDisability, accessibilityRequirements);


        // Confirmation message
        System.out.println("\nGreat! You've created a persona named " + persona.getName() +
                           " with " + capitalizeFirstLetter(selectedDisability.getType()) + ".\n");
        // Generate and display the narrative
        String narrative = persona.generateNarrative(selectedDisability.getDefinition(), selectedDisability.getImpactOnVision());
        System.out.println(narrative);

        scanner.close();
    }

    private static ColorBlindness handleColorBlindnessSelection(Scanner scanner) {
        while (true) {
            System.out.println("Pick a type of Color Blindness.");
            System.out.print("1. Protanomaly\n2. Protanopia\n3. Deuteranomaly\n4. Deuteranopia\n5. Tritanomaly\n6. Tritanopia\n\n");
            String type = scanner.nextLine().toLowerCase();
            String capitalizedType = capitalizeFirstLetter(type);
            String definition = ColorBlindness.getDefinition(type);
            if (!definition.equals("not a recognized type of color blindness.")) {
                String impact = ColorBlindness.getImpactOnVisionExplanation(type);
                return new ColorBlindness(type, capitalizedType, definition, impact);
            } else {
                System.out.println("\nInvalid Color Blindness Type, please try again.");
            }
        }
    }
    
    public static String capitalizeFirstLetter(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }
}
