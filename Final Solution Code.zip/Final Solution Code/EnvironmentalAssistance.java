package SolutionCode;
interface EnvironmentalAssistance {
    String getEnvironmentalAssistance();
}
