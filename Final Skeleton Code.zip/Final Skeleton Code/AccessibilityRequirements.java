package SkeletonCode;

import java.util.Random;

// TODO 5.0: Get AccessibilityRequirements to implement the three interfaces
public class AccessibilityRequirements {

    // TODO 5.1: Implement Constructors
    public String getRecommendedAssistiveTechnologies() {
        return null;
    }

    // TODO 5.2: Implement method
    public String getAccessibleDesignRecommendations() {
        return null;
    }
 
    // TODO 5.3: Implement method
    public String getEnvironmentalAssistance() {
        return null;
    }
    
    public String getRandomAssistance() {
        Random random = new Random();
        int choice = random.nextInt(3);
        switch (choice) {
            case 0:
                return getEnvironmentalAssistance();
            case 1:
                return getAccessibleDesignRecommendations();
            case 2:
                return getRecommendedAssistiveTechnologies();
            default:
                return "General assistance";
        }
    }
}
