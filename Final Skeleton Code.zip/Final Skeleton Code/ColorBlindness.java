package SkeletonCode;

public class ColorBlindness extends Disability {
    private String impactOnVision;
    private String type; 

    // TODO 3.0: Implement constructor
    public ColorBlindness(String type, String name, String description, String impactOnVision) {
    }

    // TODO 3.1: Implement method
    public String getImpactOnVision() {
        return null;
    }

    // TODO 3.2: Implement method
    public String getType() {
        return null;
    }

    // TODO 4.0: Give the definition of each type of color blindness
    public static String getDefinition(String colorBlindnessType) {
        switch (colorBlindnessType) {  
            case "protanomaly":
                return null;
            case "protanopia":
                return null;
            case "deuteranomaly":
                return null;
            case "deuteranopia":
                return null;
            case "tritanomaly":
                return null;
            case "tritanopia":
                return null;
            default:
                // Can stay null or add a warning message
                return null;
        }
    }
    // TODO 4.1: Explain how each type of color blindness affects someone's vision
    public static String getImpactOnVisionExplanation(String colorBlindnessType) {
        switch (colorBlindnessType) {  
            case "protanomaly":
                return null;
            case "protanopia":
                return null;
            case "deuteranomaly":
                return null;
            case "deuteranopia":
                return null;
            case "tritanomaly":
                return null;
            case "tritanopia":
                return null;
            default:
                // Can stay null or add a warning message
                return null;
        }
    }
}

