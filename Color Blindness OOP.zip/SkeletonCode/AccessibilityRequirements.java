package SkeletonCode;

import java.util.Random;

// TODO 5.0: Get AccessibilityRequirements to implement the three interfaces
public class AccessibilityRequirements {

    // TODO 5.1: Implement Constructors
    public String recommendedAssistiveTechnologies() {
        return null;
    }

    // TODO 5.2: Implement method
    public String digitalTools() {
        return null;
    }
 
    // TODO 5.3: Implement method
    public String environmentalAssistance() {
        return null;
    }
    
    public String getRandomAssistance() {
        Random random = new Random();
        int choice = random.nextInt(3);
        switch (choice) {
            case 0:
                return environmentalAssistance();
            case 1:
                return digitalTools();
            case 2:
                return recommendedAssistiveTechnologies();
            default:
                return "General assistance";
        }
    }
}
