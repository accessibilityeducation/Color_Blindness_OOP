package SkeletonCode;

// TODO 1.3: Implement interface
