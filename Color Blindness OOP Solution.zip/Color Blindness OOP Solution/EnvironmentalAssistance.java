package SolutionCode;
interface EnvironmentalAssistance {
    String environmentalAssistance();
}
