package SolutionCode;
interface AssistiveTechnology {
    String recommendedAssistiveTechnologies();
}
