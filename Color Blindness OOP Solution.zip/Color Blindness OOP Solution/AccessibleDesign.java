package SolutionCode;
interface AccessibleDesign {
    String digitalTools();
}
