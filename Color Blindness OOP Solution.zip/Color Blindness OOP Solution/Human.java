package SolutionCode;
import java.util.Random;

public class Human {
    private String name;
    private Disability disability;
    private String hobby;
    private String challenge;
    private AccessibilityRequirements accessibilityRequirements;

    public Human(String name, Disability disability, AccessibilityRequirements accessibilityRequirements) {
        this.name = name;
        this.disability = disability;
        this.accessibilityRequirements = accessibilityRequirements;
        assignRandomPersonality();
    }

    public String getName() {
        return name;
    }

    public String getDisabilityType() {
        return disability.getName();
    }

    public void setDisability(Disability disability) {
        this.disability = disability;
    }


    // Randomly assign personality attributes (hobby, challenge, supportPreference)
    public void assignRandomPersonality() {
        Random random = new Random();
        int personalityType = random.nextInt(3); // Assuming 3 types for simplicity
        
        switch (personalityType) {
            case 0: // PAINTER
                this.hobby = "painting";
                this.challenge = "distinguishing between colors";
                break;
            case 1: // GAMER
                this.hobby = "playing video games";
                this.challenge = "identifying game elements based on color";
                break;
            case 2: // GARDENER
                this.hobby = "gardening";
                this.challenge = "telling plant health by its color";
                break;
            default:
                // Optionally handle unexpected values
                break;
        }
    }
    
    public String generateNarrative(String colorBlindnessDescription, String getImpactOnVision) {
        String assistance = accessibilityRequirements.getRandomAssistance();
        return "Hello! My name is " + this.name + ", and I have " + this.disability.getName() + ". " + colorBlindnessDescription +
               " That means " + getImpactOnVision + " I love " + this.hobby + ", but sometimes I face challenges like " + this.challenge +
               ". However, using " + assistance + " This really helps me with my daily activities and enjoy my hobbies.";
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setChallenge(String challenge) {
        this.challenge = challenge;
    }

}
