package SkeletonCode;

public class Disability {
    private String name;
    private String definition;

    // TODO 2.0: Implement Constructors/Methods
    public Disability(String name, String definition) {
    }

    public String getName() {
        return null;
    }

    public String getDefinition() {
        return null;
    }
    
}

