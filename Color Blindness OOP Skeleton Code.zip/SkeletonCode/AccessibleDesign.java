package SkeletonCode;

// TODO 1.1: Implement interface

