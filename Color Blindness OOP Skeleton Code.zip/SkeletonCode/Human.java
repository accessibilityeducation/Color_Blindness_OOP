package SkeletonCode;

import java.util.Random;

public class Human {
    private String name;
    private Disability disability;
    private String hobby;
    private String challenge;
    private AccessibilityRequirements accessibilityRequirements;

    public Human(String name, Disability disability, AccessibilityRequirements accessibilityRequirements) {
        // TODO 6.0: Implement Constructor
        assignRandomPersonality();
    }

    public String getName() {
        // TODO 6.1: Implement method
        return null;
    }

    public String getDisabilityType() {
        // TODO 6.2: Implement method
        return null;
    }

    public void setDisability(Disability disability) {
        // TODO 6.3: Implement method
    }

    /*
     * OPTIONAL: You may add more personality types
     */
    // Randomly assign personality attributes (hobby, challenge, supportPreference)
    public void assignRandomPersonality() {
        Random random = new Random();
        int personalityType = random.nextInt(3);
        
        switch (personalityType) {
            case 0: // PAINTER
                this.hobby = "painting";
                this.challenge = "distinguishing between colors";
                break;
            case 1: // GAMER
                this.hobby = "playing video games";
                this.challenge = "identifying game elements based on color";
                break;
            case 2: // GARDENER
                this.hobby = "gardening";
                this.challenge = "telling plant health by its color";
                break;
            default:
                // Optional: handle unexpected values
                break;
        }
    }
    
    // TODO 6.4: This is where you will create the output for your persona. Refer to document output
    public String generateNarrative(String colorBlindnessDescription, String ImpactOnVision) {
        String assistance = accessibilityRequirements.getRandomAssistance();
        return null;
    }

    public void setHobby(String hobby) {
        // TODO 6.5: Implement method
    }

    public void setChallenge(String challenge) {
        // TODO 6.6: Implement method
    }

}

