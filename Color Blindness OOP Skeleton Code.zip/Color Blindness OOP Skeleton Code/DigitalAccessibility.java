package SkeletonCode;

// TODO 1.2: Implement interface

